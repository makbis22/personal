//2023.02.22 Class
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*2023. 02. 24
* 8. ������
*  1.1)�������� ����Ʈ ũ�� ���ϱ�
*/

int main()
{
	int* pi;
	double* pd;
	char* pc;

	printf("sizeof(pi) = %d \n", sizeof(pi));
	printf("sizeof(pd) = %d \n", sizeof(pd));
	printf("sizeof(pc) = %d \n", sizeof(pc));
	printf("sizeof(int*) = %d \n", sizeof(int*));
	printf("sizeof(double*) = %d \n", sizeof(double*));
	printf("sizeof(char*) = %d \n", sizeof(char*));

	return 0;
}
