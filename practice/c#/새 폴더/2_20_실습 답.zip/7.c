#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
    int solvent = 0, solute = 0;
    double concent = 0;

    printf("���(g)? ");
    scanf("%d", &solvent);
    printf("����(g)? ");
    scanf("%d", &solute);

    concent = ((double)solute / (double)(solute + solvent)) * 100;
    printf("��: %.2f %%\n", concent);
}