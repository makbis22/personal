#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
    unsigned int red = 0, green = 0, blue = 0;
    unsigned int mask = 0xff;
    unsigned int rgb = 0;

    printf("red? ");
    scanf("%i", &red);
    red &= mask;

    printf("green? ");
    scanf("%i", &green);
    green &= mask;


    printf("blue? ");
    scanf("%i", &blue);
    blue &= mask;

    rgb = red | (green << 8) | (blue << 16);
    printf("RGB ����: %06X\n", rgb);
}