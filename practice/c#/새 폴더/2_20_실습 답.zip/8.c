#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*/
int main(void)
{
    int elapsed_time = 0;
    const int sec_per_hour = 60 * 60;	// 1 �ð� = 3600 ��
    const int sec_per_min = 60;			// 1 �� = 60 ��
    int hour = 0, minute = 0, second = 0;
    int left = 0;

    printf("��� �ð�(��)? ");
    scanf("%d", &elapsed_time);

    hour = elapsed_time / sec_per_hour;
    left = elapsed_time % sec_per_hour;

    minute = left / sec_per_min;
    second = left % sec_per_min;

    printf("��� �ð��� %d�ð� %d�� %d���Դϴ�.\n", hour, minute, second);
}
//*/

//*
int main(void)
{
    int elapsed_time = 0;
    const int SEC_PER_HOUR = 60 * 60;	// 1 �ð� = 3600 ��
    const int SEC_PER_MIN = 60;			// 1 �� = 60 ��

    printf("��� �ð�(��) ? ");
    scanf("%d", &elapsed_time);

    int hour = elapsed_time / SEC_PER_HOUR;
    int time_left = elapsed_time % SEC_PER_HOUR;

    int minute = time_left / SEC_PER_MIN;
    int second = time_left % SEC_PER_MIN;

    printf("��� �ð���");
    hour > 0 ? printf(" %d�ð�", hour) : printf("");
    minute > 0 ? printf(" %d��", minute) : printf("");
    second > 0 ? printf(" %d��", second) : printf("");
    printf("�Դϴ�.\n");
}
//*/