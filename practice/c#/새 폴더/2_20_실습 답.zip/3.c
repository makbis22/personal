#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
    const int rate_per_kwh = 190;
    int charge = 0;
    int usage = 0;

    printf("�⺻ ���? ");
    scanf("%d", &charge);

    printf("�� ��뷮(kWh)? ");
    scanf("%d", &usage);

    charge += (usage * rate_per_kwh);
    printf("���� ���: %d��\n", charge);
}