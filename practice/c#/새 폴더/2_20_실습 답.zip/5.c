#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
    int temperature_f = 0;
    double temperature_c = 0;

    printf("ȭ���µ�? ");
    scanf("%d", &temperature_f);

    temperature_c = (temperature_f - 32) * 5.0 / 9.0;
    printf("%d F = %.2f C\n", temperature_f, temperature_c);
}