#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
    const int rate_per_kwh = 190;
    int usage = 0;
    int charges = 0;

    printf("�� ��뷮(kWh)? ");
    scanf("%d", &usage);

    charges = usage * rate_per_kwh;
    printf("���� ���: %d��\n", charges);
}