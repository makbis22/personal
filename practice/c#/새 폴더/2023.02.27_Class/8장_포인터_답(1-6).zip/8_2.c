#include <stdio.h>

#define SIZE 3
int main(void)
{
    double x[SIZE];
    int i;

    for (i = 0; i < SIZE; i++)
        printf("x[%d]�� �ּ�: %p\n", i, x + i);
}