#include <stdio.h>
#define SIZE 10

void get_min_max(const int* arr, int size, int* min, int* max)
{
    int i;
    *min = *max = arr[0];
    for (i = 0; i < 10; i++) {
        if (arr[i] < *min)
            *min = arr[i];
        if (arr[i] > * max)
            *max = arr[i];
    }
}

void print_array(const int* arr, int size)
{
    int i;
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int main(void)
{
    int arr[SIZE] = { 23, 45, 62, 12, 99, 83, 23, 50, 72, 37 };
    int min, max;

    printf("�迭: ");
    print_array(arr, SIZE);

    get_min_max(arr, SIZE, &min, &max);
    printf("�ִ밪: %d\n�ּҰ�: %d\n", max, min);
}