#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void get_rect_info(int width, int height, int* area, int* perimeter)
{
    *area = width * height;
    *perimeter = 2 * (width + height);
}

int main(void)
{
    int w, h, a, p;
    printf("����? ");
    scanf("%d", &w);

    printf("����? ");
    scanf("%d", &h);

    get_rect_info(w, h, &a, &p);
    printf("����: %d, �ѷ�: %d\n", a, p);
}