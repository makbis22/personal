#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define SIZE 5

double get_sum(const double* arr, int size)
{
    int i;
    double sum = 0;
    for (i = 0; i < size; i++)
        sum += arr[i];
    return sum;
}
int main(void)
{
    double x[SIZE] = { 0 };
    int i;

    printf("�Ǽ� %d���� �Է��ϼ���: ", SIZE);
    for (i = 0; i < SIZE; i++) {
        scanf("%lf", &x[i]);
    }
    printf("�հ�: %f\n", get_sum(x, SIZE));
}