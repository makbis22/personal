#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void print_array(const int* arr, int size)
{
    int i;
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int main(void)
{
    int arr[10] = { 12, 54, 23, 43, 87, 31, 67, 92, 79, 7 };
    int size = sizeof(arr) / sizeof(arr[0]);
    int* p = arr;
    int i, num;

    print_array(arr, size);
    printf("����? ");
    scanf("%d", &num);

    for (i = 0; i < size; i++) {
        *p += num;
        p++;
    }

    print_array(arr, size);
}