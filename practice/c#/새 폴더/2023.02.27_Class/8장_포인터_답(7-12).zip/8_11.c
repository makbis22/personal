#include <stdio.h>
#define SIZE 10

void print_array(const int arr[], int size)
{
    int i;
    for (i = 0; i < size; i++)
        printf("%2d ", arr[i]);
    printf("\n");
}

void sort_array(int* arr, int size)
{
    int i, j;
    int index;
    int temp;

    for (i = 0; i < size - 1; i++) {
        index = i;
        for (j = i + 1; j < size; j++) {
            if (arr[index] > arr[j])
                index = j;
        }
        if (i != index) {
            temp = arr[i];
            arr[i] = arr[index];
            arr[index] = temp;
        }
    }
}

int main(void)
{
    int data[SIZE] = { 92, 34, 76, 32, 15, 28, 41, 55, 89, 62 };

    printf("���� ��: ");
    print_array(data, SIZE);

    sort_array(data, SIZE);

    printf("���� ��: ");
    print_array(data, SIZE);
}