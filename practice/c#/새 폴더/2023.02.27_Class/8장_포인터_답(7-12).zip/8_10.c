#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define SIZE 10

void arith_seq(int* arr, int size, int diff)
{
    int i;
    for (i = 1; i < size; i++) {
        //arr[i] = arr[i - 1] + diff;
        *(arr + i) = *(arr + i - 1) + diff;
    }
}

void print_array(const int* arr, int size)
{
    int i;
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int main(void)
{
    int arr[SIZE] = { 0 };
    int diff;   // ����

    printf("ù ��° ��? ");
    scanf("%d", &arr[0]);
    printf("����? ");
    scanf("%d", &diff);

    arith_seq(arr, SIZE, diff);

    printf("��������: ");
    print_array(arr, SIZE);
}